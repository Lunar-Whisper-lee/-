#include "Login_Menu.h"
#include "System_Menu.h"
#include "Update_Menu.h"
#include "Save_Menu.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "global.h"
using namespace std;

int log_m_id;
int log_admin_id = 000000;
string log_m_password;
string log_admin_password;

class Login_Menu lg_login_menu;
class System_Menu lg_system_menu;

void Login_Menu::Menu_Design()
{
    for (int i = 0; i < 5; i++)
    {
        cout << endl;
    }
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "**         ��ӭʹ�ø�У��Ա��Ϣ����ϵͳ         **" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "||                  �˵�ѡ��                    ||" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "**   1. Ա����¼                                **" << endl;
    cout << setw(30) << " " << "**   2. ����Ա��¼                              **" << endl;
    cout << setw(30) << " " << "**   3. �˳�ϵͳ                                **" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "��ѡ�����Ĳ������: ";
}

void Login_Menu::Menu_Function()
{
    
    int type;
    ifstream infile("data.csv", ios::in);
    while (infile >> type)
    {
        Worker* p = NULL;
        if (type == 1)
        {
            p = new Teacher(teacher);
            p->Update(infile);
            staff.push_back(p);
        }
        else if (type == 2)
        {
            p = new Tester(tester);
            p->Update(infile);
            staff.push_back(p);
        }
        else if (type == 3)
        {
            p = new Servant(servant);
            p->Update(infile);
            staff.push_back(p);
        }
        else if (type == 4)
        {
            p = new Teacher_Servant(teacher_servant);
            p->Update(infile);
            staff.push_back(p);
        }

    }
    infile.close();
    int choice;
    cin >> choice;
    switch (choice)
    {
    case 1:
        cout << endl << setw(30) << " " << "** ���������ı�ţ�";
        cin >> log_m_id;
        cout << endl << setw(30) << " " << "** �������������룺";
        cin >> log_m_password;
        Worker_Login(log_m_id, log_m_password);
        break;
    case 2:
        cout << endl << setw(30) << " " << "** ���������ı�ţ�";
        cin >> log_m_id;
        cout << endl << setw(30) << " " << "** �������������룺";
        cin >> log_m_password;
        Admin_Login(log_m_id, log_m_password);
        break;
    case 3:
        cout << endl;
        cout << setw(45) << " " << "**  ��ӭ�´�ʹ�ã� **" << endl;
        staff.clear();
        exit(0);
        break;
    default:
        cout << endl << setw(45) << " " << "�����������������" << endl;
        Menu(&lg_login_menu);
        break;
    }
}

void Login_Menu::Worker_Login(int id, string m_password)
{
    int judge = 1;
    for (int i = 0; i < staff.size(); i++)
    {
        if (staff[i]->id == id)
        {

            judge = 0;
            if (m_password == staff[i]->password)
            {
                cout << endl << endl;
                cout << setw(30) << " " << "==================================================" << endl;
                cout << setw(30) << " " << "**                   ��¼�ɹ�                   **" << endl;
                cout << setw(30) << " " << "==================================================" << endl;
                cout << setw(30) << " " << "                ��ã�" << staff[i]->name << endl;
                cout << setw(30) << " " << "**         ��ӭʹ�ø�У��Ա��Ϣ����ϵͳ         **" << endl;
                cout << setw(30) << " " << "==================================================" << endl;
                cout << setw(30) << " " << "**  ���ù��ܣ�                                  **" << endl;
                cout << setw(30) << " " << "**  0. ���ص�¼�˵�                             **" << endl;
                cout << setw(30) << " " << "**  1. �鿴������Ϣ                             **" << endl;
                cout << setw(30) << " " << "**  2. �޸�����                                 **" << endl;
                cout << setw(30) << " " << "==================================================" << endl;
                cout << setw(30) << " " << "**  ��ѡ������ţ�";
                int choice;
                cin >> choice;
                switch (choice)
                {
                case 0:
                    Menu(&lg_login_menu);
                    break;
                case 1:
                    staff[i]->ShowInfo();
                    cout << endl;
                    cout << setw(30) << " " << "**  �����ѡ�������" << endl;
                    int choice2;
                    cin >> choice2;
                    if (choice2 == 0)
                    {
                        staff.clear();
                        Menu(&lg_login_menu);
                    }
                    else if (choice2 == 2)
                    {
                        password_edit(i);
                    }
                    break;
                case 2:
                    password_edit(i);
                    break;
                default:
                    cout << endl << setw(40) << " " << "����������������룡" << endl;
                    Worker_Login(id, m_password);
                    break;
                }
            }
            else
            {
                cout << endl << setw(40) << " " << "����������������룡" << endl;
                Menu(&lg_login_menu);
            }
        }
    }
    if (judge)
    {
        cout << setw(40) << " " << "�˺Ż�����������������룡" << endl;
        Menu(&lg_login_menu);
    }
}

void Login_Menu::Admin_Login(int id, string password)
{
    if (id == log_admin_id && password == "123456")
    {
        cout << endl << endl;
        cout << setw(30) << " " << "==================================================" << endl;
        cout << setw(30) << " " << "**                   ��¼�ɹ�                   **" << endl;
        cout << setw(30) << " " << "==================================================" << endl;
        Menu(&lg_system_menu);
    }
    else
    {
        cout << setw(40) << " " << "�˺Ż�����������������룡" << endl;
        Menu(&lg_login_menu);
    }
}

void password_edit(int cnt)
{
    cout << endl;
    cout << setw(30) << " " << "** �������޸����룺";
    cin >> log_m_password;
    cout << endl;
    string password_temp;
    cout << setw(30) << " " << "** ��ȷ�����룺";
    cin >> password_temp;
    if (password_temp == log_m_password)
    {
        cout << endl;
        staff[cnt]->password = log_m_password;
        ofstream outfile("data.csv", ios::out);
        clearfile("data.csv");
        for (auto* p : staff)
        {
            p->Save();
        }
        outfile.close();
        cout << setw(30) << " " << "** �޸ĳɹ��������µ�¼��" << endl;
        Menu(&lg_login_menu);
    }
    else
    {
        cout << endl;
        cout << setw(30) << " " << "ȷ���������޸����벻һ�£������������룡" << endl;
        password_edit(cnt);
    }
}