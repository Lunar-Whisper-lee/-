#ifndef __SAVE_MENU_H
#define __SAVE_MENU_H

#include "Menu.h"
#include <string>

using namespace std;

class Save_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

};

void clearfile(const string& filename);

#endif
