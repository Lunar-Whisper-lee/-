#ifndef __STAFF_H
#define __STAFF_H

#include "Worker.h"
using namespace std;

//��ʦ��
class Teacher : virtual public Worker
{
public:
	string department; //����ϵ
	string major;	  //רҵ
	string T_title;	  //ְ��

	Teacher(string sort, int id , string name, string gender, int age, string department, string major, string T_title, string password):
		Worker(sort, id, name, gender, age, password),
		department(department), major(major), T_title(T_title) {}
	//�������캯��
	Teacher(const Teacher& other):
		Worker(other), department(other.department), major(other.major), T_title(other.T_title) {}
	//���������
	Teacher& operator=(const Teacher& other)
	{
		if (this == &other)
			return *this;
		Worker::operator=(other);
		department = other.department;
		major = other.major;
		T_title = other.T_title;
		return *this;
	}
	int GetId() override;
	void ShowInfo() override;
	void Save() override;
	void Update(ifstream& in_file) override;
	void SetStaff(string sort, int id, string name, string gender, int age, string department, string major, string T_title, string password);
	void SetName();
	void SetGender();
	void SetAge();
	void SetDepartment();
	void SetMajor();
	void SetT_title();
};


//ʵ��Ա��
class Tester : virtual public Worker
{
public:
	string lab;		   //����ʵ����
	string position;   //ְ��
public:
	Tester(string sort, int id, string name, string gender, int age, string lab, string position, string password):
		Worker(sort, id, name, gender, age, password),
		lab(lab), position(position) {}
	//�������캯��
	Tester(const Tester& other):
		Worker(other), lab(other.lab), position(other.position) {}
	//���������
	Tester& operator=(const Tester& other)
	{
		if (this == &other)
			return *this;
		Worker::operator=(other);
		lab = other.lab;
		position = other.position;
		return *this;
	}
	int GetId() override;
	void ShowInfo() override;
	void Save() override;
	void Update(ifstream& in_file) override;
	void SetStaff(string sort, int id, string name, string gender, int age, string lab, string position, string password);
	void SetName();
	void SetGender();
	void SetAge();
	void SetLab();
	void SetPosition();
};


//������Ա��
class Servant : virtual public Worker
{
public:
	string Pol_status;	//������ò
	string S_title;		//ְ��
public:
	Servant(string sort, int id, string name, string gender, int age, string Pol_status, string S_title, string password): 
		Worker(sort, id, name, gender, age, password),
		Pol_status(Pol_status), S_title(S_title) {}
	//�������캯��
	Servant(const Servant& other):
		Worker(other), Pol_status(other.Pol_status), S_title(other.S_title) {}
	//���������
	Servant& operator=(const Servant& other)
	{
		if (this == &other)
			return *this;
		Worker::operator=(other);
		Pol_status = other.Pol_status;
		S_title = other.S_title;
		return *this;
	}
	int GetId() override;
	void ShowInfo() override;
	void Save() override;
	void Update(ifstream& in_file) override;
	void SetStaff(string sort, int id, string name, string gender, int age, string Pol_status, string S_title, string password);
	void SetName();
	void SetGender();
	void SetAge();
	void SetPol_status();
	void SetS_title();
};


//��ʦ��������Ա��
class Teacher_Servant :  public Teacher,  public Servant
{
public:
	Teacher_Servant(string sort, int id, string name, string gender, int age, string department, string major, string T_title, string Pol_status, string S_title, string password):
		Worker(sort, id, name, gender, age, password),
		Teacher(sort, id, name, gender, age, department, major, T_title, password),
		Servant(sort, id, name, gender, age, Pol_status, S_title, password) {}
	//�������캯��
	Teacher_Servant(const Teacher_Servant& other)
		: Worker(other), Teacher(other), Servant(other) {}
	//���������
	Teacher_Servant& operator=(const Teacher_Servant& other)
	{
		if (this == &other)
			return *this;
		Worker::operator=(other);
		Teacher::operator=(other);
		Servant::operator=(other);
		return *this;
	}
	int GetId() override;
	void ShowInfo() override;
	void Save() override;
	void Update(ifstream& in_file) override;
	void SetStaff(string sort, int id, string name, string gender, int age, string department, string major, string T_title, string Pol_status, string S_title, string password);
	void SetName();
	void SetGender();
	void SetAge();
	void SetDepartment();
	void SetMajor();
	void SetT_title();
	void SetPol_status();
	void SetS_title();
};


#endif
