#ifndef __WORKER_H
#define __WORKER_H

#include <iostream>
#include <string>

using namespace std;

//������Ա��
class Worker
{
public:
	string sort;
	int id;
	string name;
	string gender; 
	int age;
	string password;
public:
	Worker(string sort,int id, string name, string gender, int age, string password) : sort(sort), id(id), name(name), gender(gender), age(age) , password(password){}
	// �������캯��
	Worker(const Worker& other) : sort(other.sort), id(other.id), name(other.name), gender(other.gender), age(other.age) ,password(other.password){}
	// ���������
	Worker& operator=(const Worker& other)
	{
		if (this == &other)
			return *this;
		sort = other.sort;
		id = other.id;
		name = other.name;
		gender = other.gender;
		age = other.age;
		password = other.password;
		return *this;
	}
	virtual void Save() = 0;
	virtual void Update(ifstream& in_file) = 0;
	virtual void ShowInfo() = 0;
	virtual int GetId() = 0;
	virtual ~Worker() {}
};


#endif
