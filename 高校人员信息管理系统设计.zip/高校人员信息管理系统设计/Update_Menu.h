#ifndef __UPDATE_MENU_H
#define __UPDATE_MENU_H

#include "Menu.h"

class Update_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

};

#endif