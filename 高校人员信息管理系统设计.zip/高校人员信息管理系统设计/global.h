#ifndef __GLOBAL_H
#define __GLOBAL_H

#include "Staff.h"
#include <iomanip>
#include <vector>

extern Teacher teacher;
extern vector<Teacher> teachers;

extern Tester tester;
extern vector<Tester> testers;

extern Servant servant;
extern vector<Servant> servants;

extern Teacher_Servant teacher_servant;
extern vector<Teacher_Servant> teacher_servants;

//ȫ��Ա��
extern vector<Worker*> staff;


#endif