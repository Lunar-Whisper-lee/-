#ifndef __CONSULT_H
#define __CONSULT_H

#include "Menu.h"
#include <string>
using namespace std;

class Consult_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();
};

//ģ����ѯɸѡ������
class Consult_Condition
{
public:
    string cc_name;
    string cc_gender;
    int cc_age_bgn = 0;
    int cc_age_end = 99;
};

void Consult_All();

void Consult_ID();
void judge_function();
void Fuzzy_Consult();
void page_show(int* page);
void Condition_choice(int* choice);
void Condition_Design(int* choice, int flag);
void Judge_Condition();

#endif
