#ifndef __LOGIN_MENU_H__
#define __LOGIN_MENU_H__

#include "Menu.h"
#include <string>

using namespace std;

class Login_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

    //��¼�ӿ�
    void Worker_Login(int id, string m_password);
    void Admin_Login(int id, string password);
};

void password_edit(int cnt);

#endif
