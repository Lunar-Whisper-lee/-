#ifndef __STATISTICS_MENU_H
#define __STATISTICS_MENU_H

#include "Menu.h"

class Statistics_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

};

class Number_Statistic
{
public:
    void Get_Gender();
    void Get_Profession();
    void Get_Age();
};

void Sort_Staff();

//�����Լ��
int Get_GCD(int a, int b);
void function_jump();
#endif
