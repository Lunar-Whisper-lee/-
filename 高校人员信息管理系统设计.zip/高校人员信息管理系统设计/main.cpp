#include <iostream>
#include "Login_Menu.h"
#include "global.h"


using namespace std;

class Login_Menu m_login_menu;

void Demo()
{
	Menu(&m_login_menu);
}

int main()
{
	Demo();
	return 0;
}
