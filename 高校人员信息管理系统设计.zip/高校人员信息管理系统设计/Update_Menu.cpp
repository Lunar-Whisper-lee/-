#include <iostream>
#include <string>
#include <fstream>
#include "global.h"
#include "System_Menu.h"
#include "Update_Menu.h"

using namespace std;

System_Menu u_system_menu;

void Update_Menu::Menu_Design()
{
	for (int i = 0; i < 5; i++)
	{
		cout << endl;
	}
	cout << setw(45) << " " << "**  ���ڸ�������...  **" << endl << endl;
}

void Update_Menu::Menu_Function()
{
	staff.clear();
	int type;
	ifstream infile("data.csv", ios::in);
	if (!infile.is_open())
	{
		cout << setw(45) << " " << "** �ļ���ʧ�ܣ�" << endl;
		Menu(&u_system_menu);
	}
	while (infile >> type)
	{
		Worker* p = NULL;
		if (type == 1)
		{
			p = new Teacher(teacher);
			p->Update(infile);
			staff.push_back(p);
		}
		else if (type == 2)
		{
			p = new Tester(tester);
			p->Update(infile);
			staff.push_back(p);
		}
		else if (type == 3)
		{
			p = new Servant(servant);
			p->Update(infile);
			staff.push_back(p);
		}
		else if (type == 4)
		{
			p = new Teacher_Servant(teacher_servant);
			p->Update(infile);
			staff.push_back(p);
		}
		
	}
	if (staff.size() > 0)
	{
		cout << setw(45) << " " << "���ݸ��³ɹ���" << endl;
		cout << setw(40) << " " << "������ " << staff.size() << " �����ݡ�" << endl;
		cout << setw(45) << " " << "���ڷ���ϵͳ�˵�" << endl;
		Menu(&u_system_menu);
	}
	else
	{
		cout << setw(45) << " " << "���ݸ���ʧ�ܣ�" << endl;
		cout << setw(45) << " " << "δ�ҵ���Ч���ݡ�" << endl;
		cout << setw(45) << " " << "���ڷ���ϵͳ�˵�" << endl;
		Menu(&u_system_menu);
	}
}