#include "Staff.h"
#include <vector>
#include <fstream>
#include <sstream>
using namespace std;

int Teacher::GetId()
{
	return id;
}

void Teacher::ShowInfo()
{
	cout << "  ְҵ��" << this->sort;
	cout << "  ��ţ�" << this->id;
	cout << "  ������" << this->name;
	cout << "  �Ա�" << this->gender;
	cout << "  ���䣺" << this->age;
	cout << "  ϵ����" << this->department;
	cout << "  רҵ��" << this->major;
	cout << "  ְ�ƣ�" << this->T_title;
}

void Teacher::SetStaff(string sort, int id, string name, string gender, int age, string department, string major, string T_title, string password)
{
	this->sort = sort;
	this->id = id;
	this->name = name;
	this->gender = gender;
	this->age = age;
	this->department = department;
	this->major = major;
	this->T_title = T_title;
	this->password = password;
}

void Teacher::Save()
{
	ofstream outfile("data.csv", ios::app);
	if (!outfile)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
		return;
	}
	outfile << "1 " << this->sort << " " << this->id << " " << this->name << " " << this->gender << " " << this->age << " " << this->department << " " << this->major << " " << this->T_title << " " << this->password << endl;
	outfile.close();
}

void Teacher::Update(ifstream& in_file)
{
	in_file >> sort >> id >> name >> gender >> age >> department >> major >> T_title >> password;
}

void Teacher::SetName()
{
	string m_name;
	cin >> m_name;
	this->name = m_name;
}

void Teacher::SetGender()
{
	string m_gender;
	cin >> m_gender;
	this->gender = m_gender;
}

void Teacher::SetAge()
{
	int m_age;
	cin >> m_age;
	this->age = m_age;
}

void Teacher::SetDepartment()
{
	string m_department;
	cin >> m_department;
	this->department = m_department;
}

void Teacher::SetMajor()
{
	string m_major;
	cin >> m_major;
	this->major = m_major;
}

void Teacher::SetT_title()
{
	string m_T_title;
	cin >> m_T_title;
	this->T_title = m_T_title;
}

int Tester::GetId()
{
	return id;
}

void Tester::ShowInfo()
{
	cout << "  ְҵ��" << this->sort;
	cout << "  ��ţ�" << this->id;
	cout << "  ������" << this->name;
	cout << "  �Ա�" << this->gender;
	cout << "  ���䣺" << this->age;
	cout << "  ʵ���ң�" << this->lab;
	cout << "  ְλ��" << this->position;
}

void Tester::SetStaff(string sort, int id, string name, string gender, int age, string lab, string position, string password)
{
	this->sort = sort;
	this->id = id;
	this->name = name;
	this->gender = gender;
	this->age = age;
	this->lab = lab;
	this->position = position;
	this->password = password;
}

void Tester::Save()
{
	ofstream outfile("data.csv", ios::app);
	if (!outfile)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
		return;
	}
	outfile << "2 " << this->sort << " " << this->id << " " << this->name << " " << this->gender << " " << this->age << " " << this->lab << " " << this->position << " " << this->password << endl;
	outfile.close();
}

void Tester::Update(ifstream& in_file)
{
	in_file >> sort >> id >> name >> gender >> age >> lab >> position >> password;
}

void Tester::SetName()
{
	string m_name;
	cin >> m_name;
	this->name = m_name;
}

void Tester::SetGender()
{
	string m_gender;
	cin >> m_gender;
	this->gender = m_gender;
}

void Tester::SetAge()
{
	int m_age;
	cin >> m_age;
	this->age = m_age;
}

void Tester::SetLab()
{
	string m_lab;
	cin >> m_lab;
	this->lab = m_lab;
}

void Tester::SetPosition()
{
	string m_position;
	cin >> m_position;
	this->position = m_position;
}

int Servant::GetId()
{
	return id;
}

void Servant::ShowInfo()
{
	cout << "  ְҵ��" << this->sort;
	cout << "  ��ţ�" << this->id;
	cout << "  ������" << this->name;
	cout << "  �Ա�" << this->gender;
	cout << "  ���䣺" << this->age;
	cout << "  ������ò��" << this->Pol_status;
	cout << "  ְ�ƣ�" << this->S_title;
}

void Servant::SetStaff(string sort,int id, string name, string gender, int age, string Pol_status, string S_title, string password)
{
	this->sort = sort;
	this->id = id;
	this->name = name;
	this->gender = gender;
	this->age = age;
	this->Pol_status = Pol_status;
	this->S_title = S_title;
	this->password = password;
}

void Servant::Update(ifstream& in_file)
{
	in_file >> sort >> id >> name >> gender >> age >> Pol_status >> S_title >> password;
}

void Servant::Save()
{
	ofstream outfile("data.csv", ios::app);
	if (!outfile)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
		return;
	}
	outfile << "3 " << this->sort << " " << this->id << " " << this->name << " " << this->gender << " " << this->age << " " << this->Pol_status << " " << this->S_title << " " << this->password << endl;
	outfile.close();
}

void Servant::SetName()
{
	string m_name;
	cin >> m_name;
	this->name = m_name;
}

void Servant::SetGender()
{
	string m_gender;
	cin >> m_gender;
	this->gender = m_gender;
}

void Servant::SetAge()
{
	int m_age;
	cin >> m_age;
	this->age = m_age;
}

void Servant::SetPol_status()
{
	string m_Pol_status;
	cin >> m_Pol_status;
	this->Pol_status = m_Pol_status;
}

void Servant::SetS_title()
{
	string m_S_title;
	cin >> m_S_title;
	this->S_title = m_S_title;
}

int Teacher_Servant::GetId()
{
	return id;
}

void Teacher_Servant::ShowInfo()
{
	cout << "  ְҵ��" << this->sort;
	cout << "  ��ţ�" << this->id;
	cout << "  ������" << this->name;
	cout << "  �Ա�" << this->gender;
	cout << "  ���䣺" << this->age;
	cout << "  ���ţ�" << this->department;
	cout << "  רҵ��" << this->major;
	cout << "  ְ�ƣ�" << this->T_title;
	cout << "  ������ò��" << this->Pol_status;
	cout << "  ְ�ƣ�" << this->S_title;
}

void Teacher_Servant::SetStaff(string sort, int id, string name, string gender, int age, string department, string major, string T_title, string Pol_status, string S_title, string password)
{
	this->sort = sort;
	this->id = id;
	this->name = name;
	this->gender = gender;
	this->age = age;
	this->department = department;
	this->major = major;
	this->T_title = T_title;
	this->Pol_status = Pol_status;
	this->S_title = S_title;
	this->password = password;
}

void Teacher_Servant::Save()
{
	ofstream outfile("data.csv", ios::app);
	if (!outfile)
	{
		cout << "�ļ���ʧ�ܣ�" << endl;
		return;
	}
	outfile << "4 " << this->sort << " " << this->id << " " << this->name << " " << this->gender << " " << this->age << " " << this->department << " " << this->major << " " << this->T_title << " " << this->Pol_status << " " << this->S_title << " " << this->password << endl;
	outfile.close();
}

void Teacher_Servant::Update(ifstream& in_file)
{
	in_file >> sort >> id >> name >> gender >> age >> department >> major >> T_title >> Pol_status >> S_title >> password;
}

void Teacher_Servant::SetName()
{
	string m_name;
	cin >> m_name;
	this->name = m_name;
}

void Teacher_Servant::SetGender()
{
	string m_gender;
	cin >> m_gender;
	this->gender = m_gender;
}

void Teacher_Servant::SetAge()
{
	int m_age;
	cin >> m_age;
	this->age = m_age;
}

void Teacher_Servant::SetDepartment()
{
	string m_department;
	cin >> m_department;
	this->department = m_department;
}

void Teacher_Servant::SetMajor()
{
	string m_major;
	cin >> m_major;
	this->major = m_major;
}

void Teacher_Servant::SetT_title()
{
	string m_T_title;
	cin >> m_T_title;
	this->T_title = m_T_title;
}

void Teacher_Servant::SetPol_status()
{
	string m_Pol_status;
	cin >> m_Pol_status;
	this->Pol_status = m_Pol_status;
}

void Teacher_Servant::SetS_title()
{
	string m_S_title;
	cin >> m_S_title;
	this->S_title = m_S_title;
}