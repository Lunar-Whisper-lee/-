#ifndef __EDIT_MENU_H
#define __EDIT_MENU_H

#include "Menu.h"
#include "Staff.h"

class Edit_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

    //�޸���Ϣ�ӿ�
    void Edit_Teacher(Teacher* ptr);
    void Edit_Tester(Tester* ptr);
    void Edit_Servant(Servant* ptr);
    void Edit_Tea_Svt(Teacher_Servant* ptr);
};


#endif