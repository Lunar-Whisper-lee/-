#include <iostream>
#include "System_Menu.h"
#include "Add_Menu.h"
#include "Consult_Menu.h"
#include "Edit_Menu.h"
#include "Delete_Menu.h"
#include "Statistics_Menu.h"
#include "Save_Menu.h"
#include "Update_Menu.h"
#include "Log_Menu.h"
#include "Login_Menu.h"
#include "global.h"
#include <iomanip>

using namespace std;

System_Menu s_system_menu;
Add_Menu s_add_menu;
Consult_Menu s_consult_menu;
Edit_Menu s_edit_menu;
Delete_Menu s_delete_menu;
Statistics_Menu s_statistics_menu;
Save_Menu s_save_menu;
Update_Menu s_update_menu;
Log_Menu s_log_menu;
Login_Menu s_login_menu;

//�˵�����
void System_Menu::Menu_Design()
{

    for (int i = 0; i < 5; i++)
    {
        cout << endl;
    }
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "**         ��ӭʹ�ø�У��Ա��Ϣ����ϵͳ         **" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "||                  �˵�ѡ��                    ||" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "**   1. ������Ա��Ϣ                            **" << endl;
    cout << setw(30) << " " << "**   2. ��ѯ��Ա��Ϣ                            **" << endl;
    cout << setw(30) << " " << "**   3. �޸���Ա��Ϣ                            **" << endl;
    cout << setw(30) << " " << "**   4. ɾ����Ա��Ϣ                            **" << endl;
    cout << setw(30) << " " << "**   5. ��Ա��Ϣͳ��                            **" << endl;
    cout << setw(30) << " " << "**   6. ����Ϣ���ļ�                            **" << endl;
    cout << setw(30) << " " << "**   7. ��ȡ�ļ�����                            **" << endl;
    cout << setw(30) << " " << "**   8. �鿴ϵͳ��־                            **" << endl;
    cout << setw(30) << " " << "**   9. �˳���¼                                **" << endl;
    cout << setw(30) << " " << "==================================================" << endl;
    cout << setw(30) << " " << "��ѡ�����Ĳ������: ";

}

//ϵͳ�˵�����: ͨ���������ѡ����
void System_Menu::Menu_Function()
{
    int Judge;
    cin >> Judge;
    switch(Judge)
    {
        case 1:
            Menu(&s_add_menu);
            break;
        case 2:
            Menu(&s_consult_menu);
            break;
        case 3:
            Menu(&s_edit_menu);
            break;
        case 4:
            Menu(&s_delete_menu);
            break;
        case 5:
            Menu(&s_statistics_menu);
            break;
        case 6:
            Menu(&s_save_menu);
            break;
        case 7:
            Menu(&s_update_menu);
            break;
        case 8:
            Menu(&s_log_menu);
            break;
        case 9:
            cout << endl;
            cout << setw(45) << " " << "**  ��ӭ�´�ʹ�ã� **" << endl;
            Record_Log("�û��˳��˵�¼��");
            staff.clear();
            Menu(&s_login_menu);
            break;
        default:
            cout << endl;
            cout << setw(40) << " " << "**  ����������������룡 **" << endl;
            Menu(&s_system_menu);
            break;
    }
}

