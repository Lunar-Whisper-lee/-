#ifndef __DELETE_MENU_H__
#define __DELETE_MENU_H__

#include "Menu.h"

class Delete_Menu : public AbstractMenu
{
public:

    //�˵�����
    virtual void Menu_Design();

    //�˵�����
    virtual void Menu_Function();

};

#endif
